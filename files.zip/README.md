# 📈 台股模擬投資平台

> 100萬台幣練習帳戶 · 即時台股報價 · 零成本部署

## ✨ 功能特色

- 🟢 **即時台股報價**（透過 Yahoo Finance）
- 📊 **互動走勢圖**（即時 / 5日 / 月線 / 年線）
- 💰 **模擬下單系統**（市價 / 限價、買進 / 賣出）
- 📋 **持股損益追蹤**
- 🔍 **股票搜尋與自選股管理**
- 💾 **自動存檔**（localStorage，重新整理不會消失）

## 🚀 部署到 GitHub Pages（5分鐘完成）

### 第一步：建立 GitHub 帳號
1. 前往 https://github.com，點 **Sign up** 免費註冊
2. 驗證 Email 完成帳號建立

### 第二步：建立新的 Repository
1. 登入後點右上角 **「＋」** → **New repository**
2. Repository name 填入：`tw-stock-simulator`（或任何名稱）
3. 確認設定為 **Public**（Public 才能用免費 GitHub Pages）
4. 勾選 **Add a README file**
5. 點 **Create repository**

### 第三步：上傳檔案
1. 進入剛建立的 repo 頁面
2. 點 **Add file** → **Upload files**
3. 將以下三個檔案拖曳上傳：
   - `index.html`
   - `style.css`
   - `app.js`
4. 在 Commit changes 輸入「Initial release」
5. 點 **Commit changes**

### 第四步：啟用 GitHub Pages
1. 進入 repo 頁面，點上方 **Settings** 齒輪圖示
2. 左側選單找到 **Pages**
3. Source 選 **Deploy from a branch**
4. Branch 選 **main**，資料夾選 **/ (root)**
5. 點 **Save**
6. 等待約 **1-3 分鐘**

### 第五步：開始使用！
- 網址格式為：`https://你的帳號名稱.github.io/tw-stock-simulator/`
- 例如：`https://leo123.github.io/tw-stock-simulator/`

---

## 📖 使用說明

| 功能 | 操作方式 |
|------|---------|
| 查看個股 | 點擊左側自選股清單 |
| 新增自選股 | 點「新增」或上方搜尋框輸入代號 |
| 買進股票 | 選好股票後，右下選擇數量點「買進下單」 |
| 賣出股票 | 點「賣出」頁籤後下單 |
| 查看持股損益 | 右側面板「持股」頁籤 |
| 查看交易紀錄 | 右側面板「委託紀錄」頁籤 |
| 切換K線週期 | 圖表上方的「即時/5日/1月/3月/1年」 |

## 📌 注意事項

- 報價資料來自 Yahoo Finance（開盤期間約 15 分鐘延遲）
- 交易資料存在瀏覽器，清除 Cookie 會重置
- 僅供練習使用，非真實投資建議
